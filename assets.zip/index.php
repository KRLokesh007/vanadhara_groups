<?php include('header.php');?>

<!--Video Section-->
    <section class="content-section video-section fables-after-overlay"> 
      <div class="pattern-overlay">
      <a id="bgndVideo" class="player" data-property="{videoURL:'https://www.youtube.com/watch?v=4g8RdUe9bO4',containment:'.video-section', quality:'large',mute: 'true' ,autoPlay:true, opacity:1}">bg</a>
        <div class="container position-relative z-index">
           <div class="fables-video-caption text-center wow zoomIn" data-wow-delay="1s" data-wow-duration="2s"> 
              <h1 class="white-color font-weight-bold mt-6">Dont wait to buy land,buy land and wait</h1>  
              <p class="fables-fifth-text-color mt-3 mb-4 font-18">
                  An Sai Tejaswini Infra Developers
              </p>
              <a data-fancybox href="https://www.youtube.com/watch?v=4g8RdUe9bO4">
                 <span class="fables-iconplay fables-second-text-color fa-4x wow bounce"></span> 
              </a> 
              
          </div>
        </div>
      </div>
    </section>
<!--Video Section Ends Here--> 
    
     


<!-- Start page content --> 
       <div class="container">
           <div class="row mt-3 mt-lg-5">
               <div class="col-12 col-lg-6 mt-3 mt-lg-0 overflow-hidden">
                   <h2 class="fables-second-text-color font-35 font-weight-bold wow fadeInLeft">Who We   <span class="fables-main-text-color">Are</span></h2>
                   <p class="fables-forth-text-color mt-4 mb-4" style="text-align: justify;">
                     SAI TEJASWINI INFRA DEVELOPERS is one of the fastest growing companies in the country with interests in Township Development, Constructions, and Infrastructure sectors. We have always been in forefront in creating bench marks in the Real Estate Industry running high with more than 3 successful projects in the kitty. With the strong vision to be the India's Leading and most admired real estate company, it relies on the fact of developing and delivering unique and integrated lifestyle thus focusing on the strong project execution, high quality infrastructure as well as the customer-centric approach. We have established our client base at Hyderabad and are spreading our wings throughout Telangana.
                   </p>  
                   <!--<div class="position-relative mb-3 wow bounceInDown" data-wow-delay=".3s"> 
                       <p class="fables-fifth-text-color fables-dots-text">
                            <span class="fables-dots-circle fables-second-before fables-second-border-color"></span>
                              Quality Policy
                       </p>
                   </div>-->
                   <div class="position-relative mb-3 wow bounceInDown" data-wow-delay=".6s">
                       <p class="fables-fifth-text-color fables-dots-text">
                            <span class="fables-dots-circle fables-second-before fables-second-border-color"></span>
                            Ethical Practice
                       </p>
                   </div>
                   <div class="position-relative mb-3 wow bounceInDown" data-wow-delay=".9s">
                       <p class="fables-fifth-text-color fables-dots-text">
                            <span class="fables-dots-circle fables-second-before fables-second-border-color"></span>
                             Integrity
                       </p>
                   </div>
                   <div class="position-relative mb-3 wow bounceInDown" data-wow-delay="1.2s">
                       <p class="fables-fifth-text-color fables-dots-text">
                            <span class="fables-dots-circle fables-second-before fables-second-border-color"></span>
                             Teamwork & collaboration
                       </p>
                   </div>
                   <div class="position-relative mb-3 wow bounceInDown" data-wow-delay="1.2s">
                       <p class="fables-fifth-text-color fables-dots-text">
                            <span class="fables-dots-circle fables-second-before fables-second-border-color"></span>
                             Commitment
                       </p>
                   </div>
                   
                   
               </div>

               <div class="col-12 col-lg-6"> 
                   <div class="border-surround">

                           <img src="assets/custom/images/about_section.jpg" alt="" class="img-fluid together-abs-img wow fadeIn Believe-align" >
                        
                      
                   </div>
                   
               </div>
           </div>
</div>





<section>
<div class="fables-testimonial fables-after-overlay fables-about-caption py-5 bg-rules" style="background-image: url(assets/custom/images/index2-overlay.jpg);">
           <div class="container">
               <div class="row">
                   <div class="position-relative z-index col-12 col-md-8 offset-md-2 text-center wow zoomIn" data-wow-duration="2s"> 
                           <h3 class=" white-color mb-3 font-25 font-weight-bold">We are the best infra developers ever!!</h3> 
                          
                           <a href="#" class="btn fables-second-background-color white-color white-color-hover fables-btn-rounded  mt-4 py-2 px-5">Contact us</a>   
                   </div> 
               </div>
               
           </div>
       </div>

</section>













       

<div class="container">
           <div class="row my-4 my-md-5 ourservices">
                <div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 text-center">
                    <h2 class="font-35 font-weight-bold fables-second-text-color mb-4">Why Choose Us</h2>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay=".4s" data-wow-duration="1.5s"> 
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3"> 
                            <span class="fa fa-search fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                            <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">Transparency</h2>
                            <div class="font-15 fables-forth-text-color">
                               Transparency is the base for the trust. By being transparent, open and honest in all our dealings, by walking our talk, we are committed for mutual growth and trust.
                            </div>

                        </div>
                    </div> 
                </div>
                <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay=".8s" data-wow-duration="1.5s">  
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-building fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">QUALITY</h2>
                           <div class="font-15 fables-forth-text-color">
                                 Ultimate quality is the single element we strive to offer for the value for the customers’ money. The location, features and quality of work show what we really matter in reality
                            </div>
                        </div>
                    </div> 
                </div>

                 <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay=".8s" data-wow-duration="1.5s">  
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-users fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">
TEAMWORK</h2>
                           <div class="font-15 fables-forth-text-color">
                               We believe in joining hands to invite hearts through offering best solutions. Well coordinated, diversified, diligent and professional team ensure growth
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay="1.2s" data-wow-duration="1.5s"> 
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-hand-rock fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">PASSION</h2>
                            <div class="font-15 fables-forth-text-color">
                             Passion for achieving excellence is the DNA of our team that drives us to give our heart and soul in our work on every day basis. Passion ensures Quality.
  
                            </div>
                        </div>
                    </div> 
                </div>
          </div> 
     
       </div>
       



       </div>
       






       
       <!-- <div class="container">
           <div class="fables-team">
                <h2 class="font-35 font-weight-bold text-center fables-main-text-color my-3 my-lg-5">Team</h2> 
                <div class="row overflow-hidden">
                    <div class="col-6 col-md-3 wow bounceInDown mb-3 auto-margin" data-wow-duration="2s" data-wow-delay=".4s">
                        <div class="card fables-team-block fables-second-hover-text-color">
                           <div class="image-container shine-effect">
                               <a href="#"><img class="w-100" src="assets/custom/images/elite-md.jpg" alt="ELITE MD"></a> 
                           </div>
                          <div class="card-body">
                            <h5><a href="#" class="font-19 semi-font fables-main-text-color team-name">S V Guruswamy</a></h5>
                            <p class="font-13 fables-fifth-text-color italic my-2">Chairman & Managing Director</p> 
                            <ul class="nav fables-team-social-links"> 
                                <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                                <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                                <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                            </ul>
                          </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 wow bounceInDown mb-3 auto-margin" data-wow-duration="2s" data-wow-delay=".8s">
                        <div class="card fables-team-block fables-second-hover-text-color">
                          <div class="image-container shine-effect">
                               <a href="#"><img class="w-100" src="assets/custom/images/elite-subhashkumarjain.jpg" alt="Director"></a>
                           </div>
                          <div class="card-body">
                            <h5><a href="#" class="font-19 semi-font fables-main-text-color team-name">Subhash Kumar Jain</a></h5>
                            <p class="font-13 fables-fifth-text-color italic my-2">Director</p> 
                            <ul class="nav fables-team-social-links"> 
                                <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                                <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                                <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                            </ul>
                          </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3 wow bounceInDown mb-3 auto-margin" data-wow-duration="2s" data-wow-delay="1.2s">
                        <div class="card fables-team-block fables-second-hover-text-color">
                          <div class="image-container shine-effect">
                               <a href="#"><img class="w-100" src="assets/custom/images/elite-arumugam.jpg" alt="Director"></a>
                           </div>
                          <div class="card-body">
                            <h5><a href="#" class="font-19 semi-font fables-main-text-color team-name">S V Arumugam</a></h5>
                            <p class="font-13 fables-fifth-text-color italic my-2">Director</p> 
                            <ul class="nav fables-team-social-links"> 
                                <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                                <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                                <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-forth-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                            </ul>
                          </div>
                        </div>
                    </div>
                </div>  
               
         </div> 
       </div>   -->

              <div class="fables-index-products large-mb fables-after-overlay py-4 py-md-1 mt-md-1 bg-rules products-section" style="background-image: url(assets/custom/images/index-products-overlay.jpg);">
           <div class="container z-index position-relative overflow-hidden"> 
               <div class="row">
                   <div class="col-12 col-md-7 wow fadeInLeft">
                       <h2 class="fables-second-text-color font-35 font-weight-bold">Our <span class="white-color">On-Going Projects</span></h2>
                       <p class="fables-third-text-color mt-4 mb-md-5">
                           In its not-so-long journey, Elite has still managed to build impressive landmark projects which it could always look back with pride.
                       </p>
                   </div>
                   <div class="col-12 col-md-5 col-lg-3 text-right offset-lg-2 my-4 my-md-0 mt-md-5 mt-lg-0 text-center">
                       <a href="#" class="btn fables-second-background-color white-color white-color-hover fables-btn-rounded px-5 py-2">View more details</a>
                   </div>
               </div>   
              
       </div>  







<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active indexx">
      <div class="container">
      <div class="row mg-left">
                <div class="col-md-6 no-pad">
                    <img src="assets/custom/images/product.png" class="w-100">
                </div> 
                <div class="col-md-6 bg-white border-brown project-des">
                    <p><span class="fables-second-text-color">Project-</span>  International Swimming Pool </p>
                    <p><span class="fables-second-text-color">Location-</span>  Chennai</p>
                    <p><span class="fables-second-text-color">Client-</span> IIT Madras, Chennai</p>
                    <p><span class="fables-second-text-color">Description-</span> Olympic standard pool</p>
                </div>                  
               </div>
        
    </div>
    </div> 
    <div class="carousel-item indexx">
     <div class="container">
     <div class="row mg-left">
                <div class="col-md-6 no-pad">
                    <img src="assets/custom/images/product.png" class="w-100">
                </div> 
                <div class="col-md-6 bg-white border-brown project-des">
                    <p><span class="fables-second-text-color">Project-</span>  International Swimming Pool </p>
                    <p><span class="fables-second-text-color">Location-</span>  Chennai</p>
                    <p><span class="fables-second-text-color">Client-</span> IIT Madras, Chennai</p>
                    <p><span class="fables-second-text-color">Description-</span> Olympic standard pool</p>
                </div>                  
               </div>

</div>

    </div>
    <div class="carousel-item indexx">
     <div class="container">
<div class="row mg-left">
                <div class="col-md-6 no-pad">
                    <img src="assets/custom/images/product.png" class="w-100">
                </div> 
                <div class="col-md-6 bg-white border-brown project-des">
                    <p><span class="fables-second-text-color">Project-</span>  International Swimming Pool </p>
                    <p><span class="fables-second-text-color">Location-</span>  Chennai</p>
                    <p><span class="fables-second-text-color">Client-</span> IIT Madras, Chennai</p>
                    <p><span class="fables-second-text-color">Description-</span> Olympic standard pool</p>
                </div>                  
               </div>
 
    </div>
  </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span  class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<br>




       <!-- <div class="fables-light-background-color py-4">
           <div class="container">
               <div class="owl-carousel owl-theme nav-0 carousel-items-6 dots-0">
                  <div> 
                      <img src="assets/custom/images/ramco.jpg" alt="Clients" class="fables-partner-carousel-img ramco-img">  
                  </div>
                  <div> 
                      <img src="assets/custom/images/ascendas.jpg" alt="Clients" class="fables-partner-carousel-img">  
                  </div>
                  <div> 
                      <img src="assets/custom/images/congnizant.jpg" alt="Clients" class="fables-partner-carousel-img">  
                  </div>
                  <div> 
                      <img src="assets/custom/images/emaar.png" alt="Clients" class="fables-partner-carousel-img">  
                  </div>
                  <div> 
                      <img src="assets/custom/images/iit-madras.png" alt="Clients" class="fables-partner-carousel-img iit-logo">  
                  </div>
                  <div> 
                      <img src="assets/custom/images/ilfs.png" alt="Clients" class="fables-partner-carousel-img ilfs-logo">  
                  </div>
                </div>  
           </div> 
       </div>       -->
<!-- /End page content -->

<script>
         $(document).ready(function () {
    $('.nav li').removeClass('active');
    $('.home').addClass('active');
    $('.home a').css("color", "#e75b1e");
});
</script>
    
    
<?php include('footer.php');?>