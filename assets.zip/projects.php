<?php include('header.php');?>

<!-- Start Header -->
<div class="fables-headerprojects fables-after-overlay">
    <div class="container"> 
         <h2 class="fables-page-title fables-second-border-color">Projects Timeline</h2>
    </div> 
</div>  
<!-- /End Header -->
     
<!-- Start Breadcrumbs -->
<div class="fables-light-background-color">
    <div class="container"> 
        <nav aria-label="breadcrumb">
          <ol class="fables-breadcrumb breadcrumb px-0 py-3">
            <li class="breadcrumb-item"><a href="#" class="fables-second-text-color">Home</a></li> 
            <li class="breadcrumb-item active" aria-current="page">Projects Timeline </li>
          </ol>
        </nav> 
    </div>
</div>
<!-- /End Breadcrumbs -->
     
<!-- Start page content -->  
<div class="container"> 
   <div class="timeline multi-event-timeline">
      <span class="fables-second-background-color line"></span>
      
      <ul class="timeline-items">  
        <img  class="rounded-images" src="assets/custom/images/projects/small-circle.jpeg" width="10px">
        <li class="is-hidden timeline-item">
              <span class="gallery-mlti-date"><img class="mid-circle" src="assets/custom/images/projects/mahindhra_iris.png"></span> 
              <div class="fables-blog-cat-block blog-grid-style">  
                  <a href="project1.php"><img src="assets/custom/images/projects/mahindhra_iris.png" alt="" class="img-fluid fables-blog-img"></a>
                  <h1 class="font-15 semi-font mx-3 mt-3"><a href="#" class="fables-second-text-color fables-main-hover-color">
                      Mahindra Iris Phase-1 & 2.
                  </a></h1> 
                  <p class="fables-forth-text-color font-13 m-3">
                     The project is located at Mahindra World City, Chengalpet and it is 
                      Mahindra Integrated Township Pvt. Ltd's Residential apartments

                  </p>

             </div>
        </li>
     
        <li class="is-hidden timeline-item">
             <span class="gallery-mlti-date"><img  class="mid-circle" src="assets/custom/images/projects/international_swimming_pool.png"></span>
              <div class="fables-blog-cat-block blog-grid-style">  
                  <a href="project1.php"><img src="assets/custom/images/projects/international_swimming_pool.png" alt="" class="img-fluid fables-blog-img"></a> 
                  <h1 class="font-15 semi-font mx-3 mt-3"><a href="#" class="fables-second-text-color fables-main-hover-color">
                      International Swimming Pool
                  </a></h1> 
                  <p class="fables-forth-text-color font-13 m-3">
                     The project is located at Chennai and it is 
                      IIT Madras, Chennai's Olympic standard pool.
                  </p>

             </div> 
        </li>
         
      </ul>

      <ul class="timeline-items"> 
     <img  class="rounded-images" src="assets/custom/images/projects/small-circle.jpeg" width="10px">
        <li class="is-hidden timeline-item">
             <span class="gallery-mlti-date"><img  class="mid-circle" src="assets/custom/images/projects/nova_mahindhra_world_city.png"></span>
              <div class="fables-blog-cat-block blog-grid-style">  
                  <a href="project1.php"><img src="assets/custom/images/projects/nova_mahindhra_world_city.png" alt="" class="img-fluid fables-blog-img"></a>
                  <h1 class="font-15 semi-font mx-3 mt-3"><a href="#" class="fables-second-text-color fables-main-hover-color">
                     Nova Phase-1&2 at Mahindra World City
                  </a></h1> 
                  <p class="fables-forth-text-color font-13 m-3">
                     The project is located at Chengalpet, Tamil Nadu and it is 
                      Mahindra Integrated Township Ltd's Residential Apartments.
                  </p>

             </div>
        </li>
        <li class="is-hidden timeline-item">
             <span class="gallery-mlti-date"><img  class="mid-circle" src="assets/custom/images/projects/f_type_quarters.png"></span>
              <div class="fables-blog-cat-block blog-grid-style">
                  <a href="project1.php"><img src="assets/custom/images/projects/f_type_quarters.png" alt="" class="img-fluid fables-blog-img"></a>  
                  <h1 class="font-15 semi-font mx-3 mt-3"><a href="#" class="fables-second-text-color fables-main-hover-color">
                      F Type Quarters
                  </a></h1> 
                  <p class="fables-forth-text-color font-13 m-3">
                     The project is located at RR Nagar Township and it is a
                      Ramco Cements Ltd's 3 blocks of Stilt + 7 floors.
                  </p>

             </div>
        </li> 
      </ul>

    </div>


</div>   
<!-- /End page content -->
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
     <script>
         $(document).ready(function () {
    $('.nav li').removeClass('active');
    $('.projects').addClass('active');
    $('.projects a').css("color", "#e75b1e");
});
</script>
<?php include('footer.php');?>