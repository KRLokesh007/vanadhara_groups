<?php include('header.php')?>
     
<!-- Start Header -->
<div class="fables-header-about fables-after-overlay bg-rules">
    <div class="container"> 
         <h2 class="fables-page-title fables-second-border-color wow fadeInLeft" data-wow-duration="1.5s">About Us</h2>
    </div>
</div>  
<!-- /End Header -->
     
<!-- Start Breadcrumbs -->
<div class="fables-light-gary-background">
    <div class="container"> 
        <nav aria-label="breadcrumb">
          <ol class="fables-breadcrumb breadcrumb px-0 py-3">
            <li class="breadcrumb-item"><a href="#" class="fables-second-text-color">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
          </ol>
        </nav> 
    </div>
</div>
<!-- /End Breadcrumbs -->
     
<!-- Start page content -->  
      <!-- <div class="container">
            <div class="my-4 my-md-5 overflow-hidden">
               
                <div class="text-center mb-5 wow fadeInDown" data-wow-delay="1s">
                    <h3 class="fables-about-top-head fables-forth-text-color font-15 semi-font d-inline-block bg-white position-relative">
                        <span class="mx-4">Services</span>
                    </h3>
                    <h2 class="fables-second-text-color mt-3 font-30 font-weight-bold text-center">Provide you the great Services</h2> 
                </div> 
                    
                <div class="row">
                    <div class="col-12 col-md-4 mb-4 mb-md-0 wow fadeInDown" data-wow-delay=".3s">
                        <div class="fables-about-icon-style"> 
                            <span class="fables-second-text-color fa-3x"><i class="fas fa-eye"></i></span>
                            <h2 class="fables-second-text-color fables-about-icon-head mt-3 mb-2 font-18 semi-font">VISSION</h2>
                            <span class="fables-title-border fables-second-background-color"></span>
                            <div class="fables-forth-text-color mt-3 font-14">
                              To create meaningful spaces through real estate solutions by giving respect and value for people, money and mother nature. 
                            </div>

                        </div>
                    </div>  
                    <div class="col-12 col-md-4 mb-4 mb-md-0 wow fadeInDown" data-wow-delay=".6s">
                       <div class="fables-about-icon-style">
                           <span class="fables-second-text-color fa-3x"><i class="fas fa-rocket"></i></span>
                           <h2 class="fables-second-text-color fables-about-icon-head mt-3 mb-2 font-18 semi-font">MISSION</h2>
                           <span class="fables-title-border fables-second-background-color"></span>
                           <div class="fables-forth-text-color mt-3 font-14">
                               To become No 1 destination in the field of affordable, value for money, reliable real estate company aligning the principles of nature 
                            </div>
                        </div> 
                    </div>
                    <div class="col-12 col-md-4 mb-4 mb-md-0 wow fadeInDown" data-wow-delay=".9s">
                       <div class="fables-about-icon-style"> 
                            <span class="fables-second-text-color fa-3x"><i class="fas fa-search"></i></span>
                           <h2 class="fables-second-text-color fables-about-icon-head mt-3 mb-2 font-18 semi-font">FOCUS</h2>
                           <span class="fables-title-border fables-second-background-color"></span>
                            <div class="fables-forth-text-color mt-3 font-14">
                                Our innovative initiatives are customer focused. We keep the needs of the customers and develop the solutions through real estate projects. 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
       </div>-->
       
       
       
       
       <div class="fables-counter-no-background my-4 my-md-5 overflow-hidden">
           <div class="container">
               <div class="fables-about-head-style">
                    <div class="row wow fadeInDown" data-wow-delay=".5s">
                        <div class="col-12 text-center">
                            <h3 class="fables-about-top-head fables-forth-text-color font-15 semi-font d-inline-block bg-white position-relative">
                                <span class="mx-4">About us</span>
                            </h3>
                            <h2 class="fables-second-text-color mt-3 font-30 font-weight-bold text-center">Our business experties Provide you the great value</h2>  
                        </div>
                        <div class="col-12 col-md-10 offset-md-1 mt-3 mb-5">
                            <p class="fables-forth-text-color text-center">
                                SAI TEJASWINI INFRA DEVELOPERS is one of the fastest growing companies in the country with interests in Township Development, Constructions, and Infrastructure sectors. We have always been in forefront in creating bench marks in the Real Estate Industry running high with more than 3 successful projects in the kitty. With the strong vision to be the India's Leading and most admired real estate company, it relies on the fact of developing and delivering unique and integrated lifestyle thus focusing on the strong project execution, high quality infrastructure as well as the customer-centric approach. We have established our client base at Hyderabad and are spreading our wings throughout Telangana.
                            </p>
                        </div> 
                    </div>
                </div>
           </div>
       </div>
       
       
       
       <div class="container-fluid"> 
           <div class="row overflow-hidden">
               <div class="col-12 col-sm-6 p-sm-0 mb-3 mb-md-0 image-container translate-effect-right wow fadeInLeft" data-wow-durationn="2.5s">
                   <img src="assets/custom/images/528056-1M05og1492827243.jpg" alt="Fables Template" class="img-fluid">
               </div>
               <div class="col-12 col-sm-6 p-sm-0 image-container translate-effect-right wow fadeInRight" data-wow-durationn="2.5s">
                   <img src="assets/custom/images/Non-Owner.jpg" alt="Fables Template" class="img-fluid">
               </div>
           </div>
           
       </div>
       
       
       
       
    <div class="container">
           <div class="row my-4 my-md-5 ourservices">
                <div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 text-center">
                    <h2 class="font-35 font-weight-bold fables-second-text-color mb-4">What We Believe</h2>
                </div>
                <div class="col-12 col-sm-6 col-lg-3  pt-3 pt-md-5 wow zoomIn" data-wow-delay=".4s" data-wow-duration="1.5s"> 
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3"> 
                            <span class="fa fa-search fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                            <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">Quality Policy</h2>
                            <div class="font-15 fables-forth-text-color">
                             <p>Sai Tejaswini Infra Developers is committed to achieve complete customer satisfaction by providing highest Quality of Products & Services, through continual
                             technology upgradation, staff training focused on providing Quality service to customer by implementing Quality Management System across the organization.</p>
                            </div>

                        </div>
                    </div> 
                </div>
                <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay=".8s" data-wow-duration="1.5s">  
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-building fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">Ethical Practice</h2>
                           <div class="font-15 fables-forth-text-color">
                               Ethics constitute an integral part of our day to day functioning. We strive to maintain transparency in all serviceable transaction by adhering to timely delivery.
                            </div>
                        </div>
                    </div> 
                </div>

                 <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay=".8s" data-wow-duration="1.5s">  
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-users fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">
Integrity</h2>
                           <div class="font-15 fables-forth-text-color">
                             <p>When we make a commitment, we make sure that we deliver on it – with integrity, sincerity and consistency.</p>
                            </div>
                        </div>
                    </div> 
                </div>
                
             
                
            
                
                <div class="col-12 col-sm-6 col-lg-3 pt-3 pt-md-5 wow zoomIn" data-wow-delay="1.2s" data-wow-duration="1.5s"> 
                    <div class="row text-center text-md-left">
                        <div class="col-12 col-md-3">
                            <span class="fa fa-hand-rock fables-second-text-color fa-3x"></span>
                        </div>
                        <div class="col-12 col-md-9 pl-md-0">
                           <h2 class="fables-main-text-color font-20 my-2 mt-md-0 semi-font">Teamwork&collaboration</h2>
                            <div class="font-15 fables-forth-text-color">
                            <p>we value our employees and work on an ongoing basis to strengthen the bond of mutual respect.</p>
  
                            </div>
                        </div>
                    </div> 
                </div>
          </div> 
       </div>
       



       </div>  
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
     
    <div class="container"> 
        <div class="fables-team">             
            <div class="row wow fadeInDown">
                <div class="col-12 text-center mt- mt-md-5">
                    <h3 class="fables-about-top-head fables-forth-text-color font-15 semi-font d-inline-block bg-white position-relative">
                        <span class="mx-4">Team</span>
                    </h3>
                    <h2 class="fables-second-text-color mt-3 font-30 font-weight-bold text-center">Meet The Team</h2> 
                </div>
                <div class="col-12 col-md-8 offset-md-2">
                    <p class="mt-4 mt-md-3 mb-4 mb-md-5 fables-forth-text-color text-center">
                    We love what we do and we do it with passion. We value the experimentation, the reformation of the message, and the smart incentives
                    </p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-6 col-md-3 mb-4 mb-lg-0 wow fadeInDown" data-wow-delay=".3s">
                    <div class="card fables-team-block fables-team-data-hover fables-second-border-color">
                      <img class="img-fluid" src="assets/custom/images/team1-1.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5><a href="#" class="team-name white-color white-color-hover">JOHN MARTIN</a></h5>
                        <p class="fables-team-pos mt-2 mb-3 italic">Programmer</p> 
                        <ul class="nav fables-team-social-links"> 
                            <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>   
                            <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                            <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                        </ul>
                      </div>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-4 mb-lg-0 wow fadeInDown" data-wow-delay=".3s">
                    <div class="card fables-team-block fables-team-data-hover fables-second-border-color">
                      <img class="img-fluid" src="assets/custom/images/team1-2.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5><a href="#" class="team-name white-color white-color-hover">JOHN MARTIN</a></h5>
                        <p class="fables-team-pos mt-2 mb-3 italic">Programmer</p> 
                        <ul class="nav fables-team-social-links"> 
                            <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>   
                            <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                            <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                        </ul>
                      </div>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-4 mb-lg-0 wow fadeInDown" data-wow-delay=".3s">
                    <div class="card fables-team-block fables-team-data-hover fables-second-border-color">
                      <img class="img-fluid" src="assets/custom/images/team1-3.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5><a href="#" class="team-name white-color white-color-hover">JOHN MARTIN</a></h5>
                        <p class="fables-team-pos mt-2 mb-3 italic">Programmer</p> 
                        <ul class="nav fables-team-social-links"> 
                            <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>   
                            <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                            <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                        </ul>
                      </div>
                    </div>
                </div>
                <div class="col-6 col-md-3 mb-4 mb-lg-0 wow fadeInDown" data-wow-delay=".3s">
                    <div class="card fables-team-block fables-team-data-hover fables-second-border-color">
                      <img class="img-fluid" src="assets/custom/images/team1-4.jpg" alt="Card image cap">
                      <div class="card-body">
                        <h5><a href="#" class="team-name white-color white-color-hover">JOHN MARTIN</a></h5>
                        <p class="fables-team-pos mt-2 mb-3 italic">Programmer</p> 
                        <ul class="nav fables-team-social-links"> 
                            <li><a href="#" target="_blank"><span class="fables-iconlinkedin-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>   
                            <li><a href="#" target="_blank"><span class="fables-icontwitter-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li>
                            <li><a href="#" target="_blank"><span class="fables-iconinstagram-icon fables-second-text-color fables-fifth-border-color fables-team-social-icon"></span></a></li> 
                        </ul>
                      </div>
                    </div> 
                </div>
            </div>  
               
        </div>       
       

      </div>


      <br>
<!-- /End page content -->
   <script>
         $(document).ready(function () {
    $('.nav li').removeClass('active');
    $('.index_menu_about').addClass('active');
    $('.index_menu_about a').css("color", "#e75b1e");
});
</script>

    
<?php include('footer.php')?>