<?php include('header.php')?>
 
     
<!-- Start Header -->
<div class="fables-headerprojects bck-img-css fables-after-overlay">
    <div class="container mob-margin-css"> 
         <h2 class="fables-page-title fables-second-border-color">Tejaswini Projects</h2>
    </div>
</div>  
<!-- /End Header -->
      
<!-- Start Breadcrumbs --> 
<div class="fables-light-gary-background">
    <div class="container"> 
        <nav aria-label="breadcrumb">
          <ol class="fables-breadcrumb breadcrumb px-0 py-3">
            <li class="breadcrumb-item"><a href="#" class="fables-second-text-color">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Projects</li>
          </ol>
        </nav> 
    </div>
</div>
<!-- /End Breadcrumbs -->
     
<!-- Start page content -->   
<div class="container"> 
     <div class="row my-4 my-md-5">
          <div class="col-12 col-lg-6" style="">
                 <div class="fables-single-slider store-single-slider">
                     <div id="sync1" class="owl-carousel owl-theme">
                          <div class="item">
                            <img src="assets/custom/images/small-carousel1.jpg" alt="" class="w-100">
                          </div>
                          <div class="item">
                            <img src="assets/custom/images/small-carousel2.jpg" alt="" class="w-100">
                          </div>
                          <div class="item">
                            <img src="assets/custom/images/small-carousel3.jpg" alt="" class="w-100">
                          </div>

                        </div>
                     <div id="sync2" class="owl-carousel owl-theme">
                          <div class="item">
                            <img src="assets/custom/images/vaarahi.jpg" alt="" class="w-100">
                          </div>
                          <div class="item">
                            <img src="assets/custom/images/var_eng_2.jpg" alt="" class="w-100">
                          </div>
                          <div class="item">
                            <img src="assets/custom/images/var_eng_1.jpg" alt="" class="w-100">
                          </div>

                        </div> 
                 </div>
          </div> 
           <div class="col-md-6">
                <div class="" style="text-align: center;margin-bottom: 41px;">
                     <h3><b>ABOUT THE PROJECT</b></h3>
                </div>
                <div>
                    <p style="text-align: justify;">

Aarohaanandana after the grand success of unique ventures Suvidha Farm Lands-Shankarpally, Suvidha Farm Lands-Chegunta with 24/7 security in peaceful atmosphere for those who desire to spend their family time amidst nature and proven Malabar Neem Plantation programme with an option to build your dream cottage to enjoy luxury life style in most economical way. Aarohaanandana becomes a pioneer company and won hearts of the many, now we promisingly presents ABHISRI Township-DTCP approved layout with all developments which is a residential venture. ABHISRI Township facing National Highway 44(Nagpur Highway) with great committed mission of providing quality housing plots at reasonable prices.
</p>
</p>
</div>
               </div>
         
     </div>
     <div class="row">
      <div class="col-md-12">
              
          </div>
      </div>
     <div class="row" style="margin-bottom: 45px;">
        <div class="col-12">
            <nav class="fables-single-nav">
          <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <a class="fables-single-item nav-link fables-forth-text-color fables-second-active fables-second-hover-color fables-forth-after px-3 px-md-5 font-15 semi-font border-0 active rounded-0 py-3" id="nav-desc-tab" data-toggle="tab" href="#nav-desc" role="tab" aria-controls="nav-desc" aria-selected="true">DESCRIPTION</a>
            <a class="fables-single-item nav-link fables-forth-text-color fables-second-active fables-second-hover-color fables-forth-after border-0 px-3 px-md-5 font-15 semi-font rounded-0 py-3" id="nav-info-tab" data-toggle="tab" href="#nav-info" role="tab" aria-controls="nav-info" aria-selected="false">LOCATION HIGHLIGHTS</a>
            <a class="fables-single-item nav-link fables-forth-text-color fables-second-active fables-second-hover-color fables-forth-after border-0 px-3 px-md-5 font-15 semi-font rounded-0 py-3" id="nav-review-tab" data-toggle="tab" href="#nav-review" role="tab" aria-controls="nav-review" aria-selected="false">LOCATION MAP</a>
            <a class="fables-single-item nav-link fables-forth-text-color fables-second-active fables-second-hover-color fables-forth-after border-0 px-3 px-md-5 font-15 semi-font rounded-0 py-3" id="nav-review-tab1" data-toggle="tab" href="#nav-review2" role="tab" aria-controls="nav-review" aria-selected="false">PROJECT HIGHLIGHTS </a>
            <a class="fables-single-item nav-link fables-forth-text-color fables-second-active fables-second-hover-color fables-forth-after border-0 px-3 px-md-5 font-15 semi-font rounded-0 py-3" id="nav-review-tab1" data-toggle="tab" href="#nav-review3" role="tab" aria-controls="nav-review" aria-selected="false">BROCHURE</a>
          </div>
        </nav>
            <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active" id="nav-desc" role="tabpanel" aria-labelledby="nav-desc-tab">
              <p class="fables-single-info mt-4 font-15 fables-fifth-text-color">
                Aarohaanandana after the grand success of unique ventures Suvidha Farm Lands-Shankarpally, Suvidha Farm Lands-Chegunta with 24/7 security in peaceful atmosphere for those who desire to spend their family time amidst nature and proven Malabar Neem Plantation programme with an option to build your dream cottage to enjoy luxury life style in most economical way. Aarohaanandana becomes a pioneer company and won hearts of the many, now we promisingly presents ABHISRI Township-DTCP approved layout with all developments which is a residential venture. ABHISRI Township facing National Highway 44(Nagpur Highway) with great committed mission of providing quality housing plots at reasonable prices.
              </p>
          </div>
          <div class="tab-pane fade" id="nav-info" role="tabpanel" aria-labelledby="nav-info-tab">
            <div>
                
            <div class="row locat-high">
                <div class="col-md-6">
                     <ul style="">
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Very close to Yadadri Temple</span></li>
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Beside the 100 feet Road( Road from Yadadri that 33" and 30" <span style="margin-left: 27px;">Wide Roads connects Bondhugula, Somaram and Kolanupaka)</span></span></li>
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Very Near to Regional Ring Road </span></li>
                           <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Very near to 100 feet Road that connects all Nine Hills in <span style="margin-left: 27px;">Navagirulu which is 2300 Acres Project</span></span></li>
                            <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">150 feet tallest Hanuman statue in India</span></li>
                             <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Horticultural Parks, Tulasi Parks along with a 400 acres Deer Park, <span style="margin-left: 27px;">Permanent Helipad, Second Ghat Road to temple and Rope Way</span></span></li>
                        
                     </ul>
                   </div>
                   <div class="col-md-6">
                     <ul style="">
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Bus stand and Depot in 50 Acres</span></li>
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Sahyog Foundation to set up Siddha Kshetra Dham on 250 acres <span style="margin-left: 27px;">land near Rajapet</span></span></li>
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Marriage function halls and VVIP Guest Houses </span></li>
                          <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">MMTS & Metro Rail upto Rayagiri </span></li>
                           <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">ALines Road with 4 Checkposts that connects</span></li>
                            <li><i class="color-icon fa fa-check"></i><span class="mrg-txt">Raigiri  Mallapur vangapalli and Rajapet</span></li>
                            
                          
                          
                     </ul>
                   </div>
                </div>
            </div>
            
          </div>
           <div class="tab-pane fade" id="nav-review" role="tabpanel" aria-labelledby="nav-review-tab">
            <div style="width: 100%"><iframe width="100%" height="300" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=Kaslapur%2C%20Telangana%20%20502248+()&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div><br />
             <p class="fables-single-info mt-4 font-15 fables-fifth-text-color">
                
             </p>  
          </div>
          <div class="tab-pane fade" id="nav-review2" role="tabpanel" aria-labelledby="nav-review-tab">
            <div class="row" style="margin-top: 50px">
                <div class="col-md-4">
                   <div class="image-1"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Farm Lands</h4>
                   
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-2"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Wall fencing</h4>
        
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-3"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">33″ and 30″ Wide Roads</h4>
                      
                      </div>
                     </div>
                </div>
            </div>
            <div class="row" style="margin-top: 50px">
                <div class="col-md-4">
                   <div class="image-4"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Water lines every plot</h4>
                    
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-5"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Rain water harvest</h4>
                    
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-6"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">24 Hours Security</h4>
                      
                      </div>
                     </div>
                </div>
                
            </div>
            <div class="row" style="margin-top: 50px">
                <div class="col-md-4">
                   <div class="image-7"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Footpath facility</h4>
                     
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-8"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">100% Vasthu</h4>
                     
                      </div>
                     </div>
                </div>
                 <div class="col-md-4">
                   <div class="image-9"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Avenue Plantation</h4>
                     
                      </div>
                     </div>
                </div>
            </div>
            <div class="row" style="margin-top: 50px">
                <div class="col-md-4">
                   <div class="image-10"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Under ground Drainage System</h4>
                      
                      </div>
                     </div>
                </div>
                <div class="col-md-4">
                   <div class="image-11"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Electricity with street lights</h4>
                    
                      </div>
                     </div>
                </div>
                 <div class="col-md-4">
                   <div class="image-12"> 
                     <div class="overlay-ima1">
                     <h4 class="box-styles">Spot Registeration</h4>
                    
                      </div>
                     </div>
                </div>
            </div>

          </div>
           <div class="tab-pane fade" id="nav-review3" role="tabpanel" aria-labelledby="nav-review-tab">
            
            <div class="row" style="margin-top: 50px">
               <div class="col-md-4"> 
                   <div>
                       <img src="assets/custom/images/IPMG_Global_Report_FINAL-Cover.jpg" alt="" width="100%">   
                   </div>
               </div> 
               <div class="col-md-4">
                   <div style="text-align: center;">
                      <button class="button mob-width" style="vertical-align:middle"><a href="http://aarohaanandana.com/vaaraahi_form_lands.pdf" target="_blank"><span>ENGLISH BROCHURE</span></button></a>
                   </div>
                   <div style="text-align: center;">
                      <button class="button mob-width" style="vertical-align:middle"><a href="http://aarohaanandana.com/varahi_telugu_brochure.pdf" target="_blank"><span>TELUGU BROCHURE</span></button></a>
                   </div>
                   <div style="text-align: center;">
                      <button class="button mob-width" style="vertical-align:middle"><a href="http://aarohaanandana.com/Vaarahi_Application_Form.pdf" target="_blank"><span>MEMBERSHIP APPLICATION FORM</span></button></a>
                   </div>
                   <div style="text-align: center;">
                      <button class="button mob-width" style="vertical-align:middle"><span>REGISTERATION FORM</span></button>
                   </div>
               </div>
               <div class="col-md-4" style="float:right; top:8px;">
                   <div>
                       <img src="assets/custom/images/side.jpg" alt="" width="100%" height="454px">   
                   </div>
               </div>  
            </div>
            


            
          </div>
        </div>
        </div>
     </div>
    

</div> 
<!-- /End page content -->
    
<?php include('footer.php')?>